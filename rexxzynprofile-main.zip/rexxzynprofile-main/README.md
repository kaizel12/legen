<p align="center">
  <a href="https://rexxzynprofile.vercel.app">
    <img alt="Consumet" src="https://files.catbox.moe/1mubay.jpg" width="150">
  </a>
</p>

<h1 align="center">
  Simple Link Profile
</h1>
<p align="center">
  Simpel Link Profile ini dibuat agar mempermudah mencari web profil dalam satu web yang sudah tertera di website saya
</p>

For Vercel Deploy 

Gunakan Tombol Dibawah Untuk deploy repo ini ke akun vercel kalian

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https://github.com/RexxHayanasi/rexxzynprofile.git)

Contoh Card Profile

![MixCollage-20-Apr-2024-11-03-PM-197](https://files.catbox.moe/6wzheg.jpg)

☘️↑ Tampilan Awal

![MixCollage-20-Apr-2024-11-03-PM-197](https://files.catbox.moe/88qbe0.jpg)

📜 ↑ Tampilan masuk menuju profil link

Website Ini dilengkapi dengan audio auto play berdurasi 35 Detik Lagu akan auto diputar ketika sudah mengklik (≡Lihat Link)


Bergabung Dengan saya di Channel What'sapp
https://whatsapp.com/channel/0029VaHMgM3Lo4hcfGTJ3W1e
